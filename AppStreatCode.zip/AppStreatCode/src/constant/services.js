
const all = {
    serviceUrl:{
        listAll:"https://mock-backend-apiz.herokuapp.com/api/v1/products?page=",
        productdetailService:'https://mock-backend-apiz.herokuapp.com/api/v1/products/'
    }
     
}

export default all;