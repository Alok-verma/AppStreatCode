import React, { Component } from 'react';
import '../stylesheets/landingpage.css'
import * as action from '../actions/action.js'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom';

const mapStateToProps = state => ({
    GetDataState: state.GetDataReducer.GetDataState,
})
const mapDispatchToProps = dispatch => ({
    fetchGetData(pageNumber) {
        dispatch(
            action.GetDataAction(pageNumber)
        )
    },
})


class LandingPageComp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pageNumber:1,
            disabledMoreButton:false,
            disabledlessButton:true,
            isRecods:true,

           
           
        };
    }

        comma_separators(num){
        try {
            return parseFloat((num).toFixed(2)).toLocaleString();
            
        } catch (error) {
            console.log(error)
        }
        
  }
    componentDidMount() {
        this.props.fetchGetData(this.state.pageNumber)
       
    }
    setPageNumber(flag){
        try {
            if(flag){
                this.setState({
                    pageNumber:this.state.pageNumber+1
                },()=>{
                    this.props.fetchGetData(this.state.pageNumber)
                        this.enableMoreButton();
                        this.enableLessButton();
                })

            }else{
                this.setState({
                    pageNumber:this.state.pageNumber-1
                },()=>{
                    this.props.fetchGetData(this.state.pageNumber)
                        this.enableMoreButton();
                        this.enableLessButton();
                })
            }
        } catch (error) {
            console.log(error)
            
        }
    }
    enableMoreButton(){
        try {
            if(this.props.GetDataState.length ===0|| this.props.GetDataState===undefined ){
                this.setState({
                    disabledMoreButton:true,
                    })
            }
            else{
                this.setState({
                    disabledMoreButton:false,
                })
            }
                
            
        } catch (error) {
            console.log(error)
            
        }
    }
    enableLessButton(){
        try {
            if(this.state.pageNumber ===1){
                this.setState({
                disabledlessButton:true,
                })
            }else{ 
                this.setState({
                    disabledlessButton:false,
                    disabledMoreButton:false,
             })
            }
            
        } catch (error) {
            console.log(error)
            
        }
    }
   
    
   

    render() {
        const { GetDataState } = this.props
        console.log("GetDataState",GetDataState)
        return (
            <React.Fragment>
                <div className=" col-sm-12 container">
                    <div className="col-sm-12">
                        <h2 className="pointer">App Streat</h2>
                    </div>
                    <React.Fragment>
                        {(GetDataState !== undefined) ?
                            <React.Fragment>
                                {(GetDataState.length > 0) ?
                                    <React.Fragment>
                                        {GetDataState.map((iter, index) => {
                                            return (
                                                <React.Fragment key={index}>
                                                    {iter['images'].map((imglist, index) => {
                                                        return (
                                                            <React.Fragment key={index}>
                                                                <div className="column">
                                                                    <div className="card">
                                                                        <React.Fragment key={index}>
                                                                            <div className="col-sm-12">
                                                                                <img className="img-list" src={imglist} alt="" />
                                                                                <div className=" description-box d-flex justify-content-center">
                                                                                    <p className="text-lg-center-text-md-center-text-sm-center">
                                                                                        <Link to={"/filter/" + `${iter['_id']}`}>{iter.name}</Link>
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                            <div className="d-flex justify-content-center  text-white">
                                                                                <div className="p-2 rs">₹{this.comma_separators(iter.sale_price)}</div>
                                                                                <div className="p-2 dicount">₹{this.comma_separators(iter.mark_price)}</div>
                                                                                <div className="p-2 dis"><span>{iter.sale_msg}</span></div>
                                                                            </div>
                                                                        </React.Fragment>
                                                                    </div>
                                                                </div>
                                                            </React.Fragment>
                                                        )
                                                    })

                                                    }


                                                </React.Fragment>
                                            )
                                        })}
                                    </React.Fragment>

                                    :

                                    <div className="gfg-box">
                                        <div className="box">
                                            <span>No Records Found!!</span>
                                        </div>
                                    </div>
                                }
                            </React.Fragment>

                            : 
                            <React.Fragment>
                            <div className="gfg-box">
                            <i className="fa fa-circle-o-notch fa-spin" style={{fontSize:"50px",color:"blue"}}></i>
                            </div>
                        </React.Fragment>
                        }
                    </React.Fragment>
                    <div className="col-sm-12 mt-2 conatiner float-right mb-3">
                        {(this.props.GetDataState !==undefined)?
                        <React.Fragment>
                            <div className="d-flex justify-content-between mb-3">
                                <div className="p-2 "><button type="button" disabled={this.state.disabledMoreButton} onClick={(e) => { this.setPageNumber(true) }} className="btn btn-primary py-1 font-weight-bold">Show More</button></div>
                            
                                <div className="p-2 "><button type="button" disabled={this.state.disabledlessButton} onClick={(e) => { this.setPageNumber(false) }} className="btn btn-primary py-1 font-weight-bold">Show Less</button></div>
                            </div>
                            

                        </React.Fragment>:""

                        }
                       
                    </div>
                </div>
            </React.Fragment>
        )

    }
}
const LandingPage = connect(mapStateToProps, mapDispatchToProps)(LandingPageComp)
export default LandingPage
