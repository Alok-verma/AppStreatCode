import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import * as action from '../actions/action.js'
import { connect } from 'react-redux'
import ShowMore from 'react-show-more';
import Carousel from "react-elastic-carousel";

const mapStateToProps = state => ({
    getDataState: state.getDetailsDataReducer.getDataState,
})

const mapDispatchToProps = dispatch => ({
    fetchGetData(id) {
        dispatch(
            action.getDetailDataAction(id)
        )
    },
})
class DetailsPage extends Component {
    constructor(props) {
        super(props);
        this.state={
           

        }
    }

    componentDidMount(){
        const {id} = this.props.match.params
        this.props.fetchGetData(id)
    }
    comma_separators(num){
         try {
            if(num !==undefined){
                return parseFloat((num).toFixed(2)).toLocaleString();
            }
         } catch (error) {
             console.log(error)
             
         }
     
    }
    render() {
        const{getDataState}= this.props
        var prdDesc=[],prdAvilable=[]
        if(getDataState !==undefined){
             prdDesc=getDataState.primary_product 
             prdAvilable=getDataState.options

        }
     
        return (
            <div className="col-sm-12">
                {(prdDesc !== undefined) ?
                    <React.Fragment>
                        <div className="container col-sm-12 mt-2">
                        <Link to={"/"}>Go to Dashboard</Link>
                        </div>
                       
                        <div className="conatiner mt-5">
                            <div className="col-sm-12">
                                <div className="card col-sm-9 main-container">
                                    <div className="row">
                                        <div className="col-sm-6 col-md-4 auto">
                                            {(prdDesc.images !== undefined) ?
                                                <React.Fragment>
                                                    {(prdDesc.images.length > 0) ?
                                                        <React.Fragment>
                                                            <Carousel itemsToShow={1} >
                                                                {prdDesc.images.map((item, index) =>
                                                                    <div key={index}>
                                                                        <img className="img-list" src={item} alt="" />
                                                                    </div>
                                                                )}
                                                            </Carousel>
                                                        </React.Fragment>
                                                        
                                                        : ""
                                                    }
                                                </React.Fragment>
                                                 : 
                                                 <React.Fragment>
                                                        <div className="gfg-box mt-4">
                                                        <i className="fa fa-circle-o-notch fa-spin" style={{fontSize:"50px",color:"blue"}}></i>
                                                        </div>
                                                    </React.Fragment>
                                            }
                                        </div>
                                        <div className="col-sm-6 col-md-8 det">
                                            <div className=" col-sm-12 row">
                                                <div className="col-sm-12 p-2" style={{ display: "contents" }}>
                                                    <label className="font-weight-bold" >{prdDesc !== undefined ? prdDesc.name : ""}</label><br />
                                                    <div className="description text-justify">
                                                        <ShowMore
                                                            lines={2}
                                                            more='Show more'
                                                            less='Show less'
                                                            anchorClass='text-justify'
                                                        >
                                                    <span className="description">{prdDesc !== undefined ? prdDesc.desc : ""}</span>
                                                        </ShowMore>
                                                    </div>
                                                </div>
                                                <div className="col-sm-12 p-0">
                                                    <div className="d-flex text-white">
                                                        <div className="p-0 mt-2 rs">₹{this.comma_separators(prdDesc.sale_price)}</div>
                                                        <div className="p-2 dicount">₹{this.comma_separators(prdDesc.mark_price)}</div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-12 p-0">
                                                    <div className="d-flex text-white">
                                                        <div className="p-0 dis"><span> You save &nbsp;{prdDesc.sale_msg}</span></div>
                                                    </div>
                                                </div>
                                                <div className="col-sm-12 p-2">
                                                    <div className="color-avilable "><span>{prdAvilable.length} &nbsp;Color Avilable:</span></div>
                                                    <div className="radio-conatiner">
                                                        {(prdAvilable.length > 0 && prdAvilable !== undefined) ?
                                                            <React.Fragment>
                                                                {prdAvilable.map((iter, index) => {
                                                                    return (
                                                                        <React.Fragment key={index}>
                                                                            <input type="radio" id={iter._id} name={iter.attrib_id} value={iter.name} /> &nbsp;
                                                                            <label className="color-grey" for={iter.name}>{iter.name}</label> &nbsp;
                                                                        </React.Fragment>
                                                                    )
                                                                })
                                                                }
                                                            </React.Fragment> : ""
                                                        }
                                                    </div>
                                                </div>
                                                <div className="col-sm-12 p-2">
                                                    <div className="color-avilable ">5 Size Avilable:</div>
                                                    <div className="radio-conatiner">
                                                        <button type="button" className="btn btn-light mr-2">S</button>
                                                        <button type="button" className="btn btn-light mr-2">M</button>
                                                        <button type="button" className="btn btn-light mr-2">L</button>
                                                        <button type="button" className="btn btn-light mr-2">XL</button>
                                                        <button type="button" className="btn btn-light mr-2">XXL</button>

                                                    </div>
                                                </div>
                                                <div className="col-sm-12 p-2">
                                                    <div className="color-avilable "><span>Qunanity:</span></div>
                                                    <div className="radio-conatiner">
                                                        <div className="btn-group btn-group-sm">
                                                            <button type="button" className="btn btn-light">-</button>
                                                            <button type="button" className="btn btn-primary">00</button>
                                                            <button type="button" className="btn btn-light">+</button>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div className="col-sm-12 p-2">
                                                    <button type="button" className="btn btn-primary btn-sm btn-block">Add to cart</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </React.Fragment>
                    
                    :""
                    
                    
                }
            </div>
        )
    }
}
const detailsPage = connect(mapStateToProps, mapDispatchToProps)(DetailsPage)
export default detailsPage;
