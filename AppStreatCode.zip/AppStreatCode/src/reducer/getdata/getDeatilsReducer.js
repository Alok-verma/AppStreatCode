export default function getDetailsDataReducer(state = { getDataState:[]}, action)  {

    switch (action.type) {
        case 'GETDATA_STATE':
            return {
                getDataState: action.getDataState,
            }
        default:
            return state
    }

}