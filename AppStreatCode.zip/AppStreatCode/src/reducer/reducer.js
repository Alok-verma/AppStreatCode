import { combineReducers } from 'redux';
import GetDataReducer from './getdata/getservicedata.js'
import getDetailsDataReducer from './getdata/getDeatilsReducer.js'


export default combineReducers({
    GetDataReducer,
    getDetailsDataReducer
   
})