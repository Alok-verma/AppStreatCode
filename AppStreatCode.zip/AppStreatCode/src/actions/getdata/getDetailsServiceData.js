import {getDeatilsServiceData} from '../../service/detailspageService.js'
function getState(getDataState){
    return{
            type:'GETDATA_STATE',
            getDataState
    }
}
 export const getDetailDataAction=(id)=>dispatch=>{
    let getDataState = [];
    getDeatilsServiceData((data => {
            (data) ? getDataState = data : console.log('error in fetching data')
        dispatch(getState(getDataState))
    }),id)
 }