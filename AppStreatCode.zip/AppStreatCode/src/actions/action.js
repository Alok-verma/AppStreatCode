import { GetDataAction } from './getdata/getservicedata.js'
import {getDetailDataAction} from './getdata/getDetailsServiceData.js'


export {
    GetDataAction,
    getDetailDataAction
}