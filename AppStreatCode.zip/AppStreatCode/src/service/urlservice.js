import service from '../constant/services.js'
export function GetServiceData(actionCallback,pageNumber) {
    
    fetch(service.serviceUrl.listAll+pageNumber, {
        headers: new Headers({
            'Content-Type': 'application/json',
        })
    })
    .then(response => {
        if (response.status === 200 || response.status === 201 ) {
            response.json().then(json => actionCallback(json, "success"))
        } else {
            actionCallback([], "error")
        }
    })
}