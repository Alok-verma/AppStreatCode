import service from '../constant/services.js'
export function getDeatilsServiceData(actionCallback,id) {
    
    fetch(service.serviceUrl.productdetailService+id, {
        headers: new Headers({
            'Content-Type': 'application/json',
        })
    })
    .then(response => {
        if (response.status === 200 || response.status === 201 ) {
            response.json().then(json => actionCallback(json, "success"))
        } else {
            actionCallback([], "error")
        }
    })
}